import React from 'react';

const StarBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      {/* Generating stars via CSS box-shadow would be cleaner in external CSS, 
          but using inline styles for randomized positions works well for this constraint */}
      <div className="stars-layer-1 absolute w-full h-full" />
      <div className="stars-layer-2 absolute w-full h-full" />
      <div className="stars-layer-3 absolute w-full h-full" />
      
      <style>{`
        @keyframes twinkle {
          0% { opacity: 0.3; transform: scale(0.8); }
          50% { opacity: 1; transform: scale(1.2); }
          100% { opacity: 0.3; transform: scale(0.8); }
        }
        
        @keyframes moveSpace {
          from { transform: translateY(0); }
          to { transform: translateY(-100px); }
        }

        .star {
          position: absolute;
          background: white;
          border-radius: 50%;
          animation: twinkle infinite alternate;
        }
      `}</style>

      {/* Generate some random stars */}
      {Array.from({ length: 50 }).map((_, i) => (
        <div
          key={`star-${i}`}
          className="star"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            width: `${Math.random() * 3 + 1}px`,
            height: `${Math.random() * 3 + 1}px`,
            animationDuration: `${Math.random() * 3 + 2}s`,
            opacity: Math.random(),
            boxShadow: `0 0 ${Math.random() * 5 + 2}px rgba(255, 255, 255, 0.8)`
          }}
        />
      ))}
    </div>
  );
};

export default StarBackground;