
import React, { useState, useEffect, useRef } from 'react';

type GameType = 
  | 'memory' | 'reflex' | 'catch' | 'guess' | 'rps' | 'simon' | 'snake' | 'slots' | 'math'
  | 'docking' | 'mole' | 'clicker' | 'highlow' | 'lightsout' | 'jump' | 'lock' | 'difference' | 'quiz' | 'pattern' | 'stroop';

const MiniGames: React.FC = () => {
  const [activeGame, setActiveGame] = useState<GameType>('memory');

  const allGames: GameType[] = [
    'memory', 'reflex', 'catch', 'guess', 'rps', 'simon', 'snake', 'slots', 'math',
    'docking', 'mole', 'clicker', 'highlow', 'lightsout', 'jump', 'lock', 'difference', 'quiz', 'pattern', 'stroop'
  ];

  // Bileşen ilk yüklendiğinde rastgele bir oyun seç
  useEffect(() => {
    const randomGame = allGames[Math.floor(Math.random() * allGames.length)];
    setActiveGame(randomGame);
  }, []);

  const switchGame = () => {
    const otherGames = allGames.filter(g => g !== activeGame);
    const nextGame = otherGames[Math.floor(Math.random() * otherGames.length)];
    setActiveGame(nextGame);
  };

  const getTitle = () => {
    switch(activeGame) {
      case 'memory': return 'GALAKTİK HAFIZA';
      case 'reflex': return 'HİPER SÜRÜŞ REFLEKS';
      case 'catch': return 'KUYRUKLU YILDIZ AVI';
      case 'guess': return 'GİZLİ KOORDİNAT';
      case 'rps': return 'GALAKTİK DÜELLO';
      case 'simon': return 'IŞIK DİZİLİMİ';
      case 'snake': return 'YILAN NEBULASI';
      case 'slots': return 'KOZMİK SLOT';
      case 'math': return 'ROKET MATEMATİĞİ';
      case 'docking': return 'KENETLENME';
      case 'mole': return 'UZAYLI AVI';
      case 'clicker': return 'FOTON TOPLAYICI';
      case 'highlow': return 'YILDIZ FALI';
      case 'lightsout': return 'ENERJİ AĞI';
      case 'jump': return 'AY ZIPLAMASI';
      case 'lock': return 'YÖRÜNGE KİLİDİ';
      case 'difference': return 'KAMUFLAJ';
      case 'quiz': return 'ASTRO BİLGİ';
      case 'pattern': return 'YILDIZ HARİTASI';
      case 'stroop': return 'RENK REAKTÖRÜ';
      default: return 'MİNİ OYUN';
    }
  };

  return (
    <div className="w-full max-w-md mx-auto px-6 relative z-10 mb-6 mt-auto flex flex-col gap-3">
      <div className="w-full bg-black/30 backdrop-blur-md rounded-xl border border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.1)] overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="bg-white/5 p-3 border-b border-white/10 flex justify-between items-center">
          <h3 className="text-cyan-400 font-bold tracking-widest orbitron text-sm">
            {getTitle()}
          </h3>
          <button 
            onClick={switchGame}
            className="text-xs text-gray-400 hover:text-white hover:underline transition-colors cursor-pointer z-20"
          >
            Oyunu Değiştir ↻
          </button>
        </div>

        {/* Game Area */}
        <div className="p-4 min-h-[280px] flex items-center justify-center relative w-full">
          {activeGame === 'memory' && <MemoryGame />}
          {activeGame === 'reflex' && <ReflexGame />}
          {activeGame === 'catch' && <CatchGame />}
          {activeGame === 'guess' && <GuessGame />}
          {activeGame === 'rps' && <RPSGame />}
          {activeGame === 'simon' && <SimonGame />}
          {activeGame === 'snake' && <SnakeGame />}
          {activeGame === 'slots' && <SlotGame />}
          {activeGame === 'math' && <MathGame />}
          {activeGame === 'docking' && <DockingGame />}
          {activeGame === 'mole' && <MoleGame />}
          {activeGame === 'clicker' && <ClickerGame />}
          {activeGame === 'highlow' && <HighLowGame />}
          {activeGame === 'lightsout' && <LightsOutGame />}
          {activeGame === 'jump' && <JumpGame />}
          {activeGame === 'lock' && <LockGame />}
          {activeGame === 'difference' && <DifferenceGame />}
          {activeGame === 'quiz' && <QuizGame />}
          {activeGame === 'pattern' && <PatternGame />}
          {activeGame === 'stroop' && <StroopGame />}
        </div>
      </div>
    </div>
  );
};

/* ================= EXISTING GAMES ================= */

/* --- GAME 1: MEMORY --- */
const MemoryGame: React.FC = () => {
  const icons = ['🪐', '🛸', '🚀', '👽', '☄️', '🔭'];
  const [cards, setCards] = useState<any[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [solved, setSolved] = useState<number[]>([]);
  const [disabled, setDisabled] = useState(false);

  const initializeGame = () => {
    const duplicated = [...icons, ...icons];
    const shuffled = duplicated
      .sort(() => Math.random() - 0.5)
      .map((icon, index) => ({ id: index, icon }));
    setCards(shuffled);
    setFlipped([]);
    setSolved([]);
    setDisabled(false);
  };

  useEffect(() => { initializeGame(); }, []);

  const handleClick = (id: number) => {
    if (disabled || flipped.includes(id) || solved.includes(id)) return;

    if (flipped.length === 0) {
      setFlipped([id]);
      return;
    }

    if (flipped.length === 1) {
      setDisabled(true);
      const firstId = flipped[0];
      const secondId = id;
      setFlipped([firstId, secondId]);

      if (cards[firstId].icon === cards[secondId].icon) {
        setSolved(prev => [...prev, firstId, secondId]);
        setFlipped([]);
        setDisabled(false);
      } else {
        setTimeout(() => {
          setFlipped([]);
          setDisabled(false);
        }, 800);
      }
    }
  };

  if (solved.length === cards.length && cards.length > 0) {
    return (
      <div className="text-center animate-fade-in-up">
        <div className="text-4xl mb-2 animate-bounce">🏆</div>
        <p className="text-green-400 font-bold mb-4">BAŞARDIN!</p>
        <button onClick={initializeGame} className="btn-primary">Tekrar Oyna</button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-4 gap-2 w-full h-full">
      {cards.map((card) => (
        <div
          key={card.id}
          onClick={() => handleClick(card.id)}
          className={`aspect-square rounded-lg flex items-center justify-center text-2xl cursor-pointer transition-all duration-300 transform ${
            flipped.includes(card.id) || solved.includes(card.id)
              ? 'bg-cyan-900/50 rotate-y-180 scale-105 text-white shadow-[0_0_10px_rgba(34,211,238,0.3)]'
              : 'bg-white/10 hover:bg-white/20'
          }`}
        >
          {(flipped.includes(card.id) || solved.includes(card.id)) ? card.icon : '?'}
        </div>
      ))}
    </div>
  );
};

/* --- GAME 2: REFLEX --- */
const ReflexGame: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'waiting' | 'now' | 'result'>('idle');
  const [startTime, setStartTime] = useState(0);
  const [score, setScore] = useState<number | null>(null);
  const [timerId, setTimerId] = useState<any>(null);

  const startGame = () => {
    setStatus('waiting');
    const randomDelay = Math.floor(Math.random() * 2000) + 1500;
    const id = setTimeout(() => {
      setStatus('now');
      setStartTime(Date.now());
    }, randomDelay);
    setTimerId(id);
  };

  const handleAction = () => {
    if (status === 'idle') {
      startGame();
    } else if (status === 'waiting') {
      clearTimeout(timerId);
      setStatus('idle');
      alert('Çok erken! Bekle.');
    } else if (status === 'now') {
      const endTime = Date.now();
      setScore(endTime - startTime);
      setStatus('result');
    } else if (status === 'result') {
      setScore(null);
      startGame();
    }
  };

  return (
    <div 
      onClick={handleAction}
      className={`w-full h-48 rounded-xl flex flex-col items-center justify-center cursor-pointer transition-all duration-300 select-none border-2 shadow-lg
        ${status === 'idle' ? 'bg-gray-800/50 border-gray-600' : ''}
        ${status === 'waiting' ? 'bg-red-900/40 border-red-500 animate-pulse' : ''}
        ${status === 'now' ? 'bg-green-600 border-green-400 scale-105' : ''}
        ${status === 'result' ? 'bg-cyan-900/40 border-cyan-500' : ''}
      `}
    >
      {status === 'idle' && <span className="text-xl font-bold">BAŞLATMAK İÇİN DOKUN</span>}
      {status === 'waiting' && <span className="text-xl font-bold text-red-300">BEKLE...</span>}
      {status === 'now' && <span className="text-3xl font-bold text-white">BAS!</span>}
      {status === 'result' && (
        <div className="text-center">
          <span className="block text-xs text-cyan-300 mb-1">TEPKİ SÜRESİ</span>
          <span className="text-4xl font-bold text-white orbitron">{score}ms</span>
          <span className="block text-xs text-gray-400 mt-2">Tekrar için dokun</span>
        </div>
      )}
    </div>
  );
};

/* --- GAME 3: CATCH THE STAR --- */
const CatchGame: React.FC = () => {
  const [pos, setPos] = useState({ top: 50, left: 50 });
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (playing && timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0) {
      setPlaying(false);
    }
  }, [playing, timeLeft]);

  const moveStar = () => {
    setPos({
      top: Math.random() * 80 + 10,
      left: Math.random() * 80 + 10
    });
  };

  const hit = () => {
    setScore(s => s + 1);
    moveStar();
  };

  const start = () => {
    setScore(0);
    setTimeLeft(15);
    setPlaying(true);
    moveStar();
  };

  if (!playing) return (
    <div className="text-center">
      <h3 className="text-xl font-bold text-yellow-300 mb-2">SKOR: {score}</h3>
      <p className="text-sm text-gray-400 mb-4">15 saniyede kaç yıldız yakalayabilirsin?</p>
      <button onClick={start} className="btn-primary">BAŞLA</button>
    </div>
  );

  return (
    <div className="w-full h-full relative bg-black/40 rounded-lg overflow-hidden cursor-crosshair min-h-[250px]">
      <div className="absolute top-2 right-2 text-white font-bold">{timeLeft}s</div>
      <div className="absolute top-2 left-2 text-yellow-400 font-bold">{score}</div>
      <div 
        onMouseDown={hit}
        className="absolute w-10 h-10 flex items-center justify-center text-3xl cursor-pointer select-none transition-all duration-100 ease-linear active:scale-75"
        style={{ top: `${pos.top}%`, left: `${pos.left}%`, transform: 'translate(-50%, -50%)' }}
      >
        🌟
      </div>
    </div>
  );
};

/* --- GAME 4: GUESS THE NUMBER --- */
const GuessGame: React.FC = () => {
  const [target, setTarget] = useState(0);
  const [guess, setGuess] = useState('');
  const [msg, setMsg] = useState('1-100 arası bir sayı tuttum.');
  const [attempts, setAttempts] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  useEffect(() => { reset(); }, []);

  const reset = () => {
    setTarget(Math.floor(Math.random() * 100) + 1);
    setGuess('');
    setMsg('1-100 arası koordinatı bul.');
    setAttempts(0);
    setGameOver(false);
  };

  const check = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseInt(guess);
    if (isNaN(num)) return;
    
    setAttempts(p => p + 1);
    if (num === target) {
      setMsg(`DOĞRU! Koordinat ${target}.`);
      setGameOver(true);
    } else if (num < target) {
      setMsg('Daha YÜKSEK bir değer gir.');
    } else {
      setMsg('Daha DÜŞÜK bir değer gir.');
    }
    setGuess('');
  };

  return (
    <div className="text-center w-full max-w-xs">
      <p className={`mb-4 text-lg ${gameOver ? 'text-green-400 font-bold' : 'text-cyan-200'}`}>{msg}</p>
      {!gameOver ? (
        <form onSubmit={check} className="flex gap-2">
          <input 
            type="number" 
            value={guess}
            onChange={(e) => setGuess(e.target.value)}
            className="flex-1 bg-black/30 border border-gray-600 rounded px-3 py-2 text-white outline-none focus:border-cyan-500"
            placeholder="0"
            autoFocus
          />
          <button type="submit" className="btn-secondary px-4">Tahmin Et</button>
        </form>
      ) : (
        <div>
           <p className="text-sm text-gray-400 mb-2">Deneme: {attempts}</p>
           <button onClick={reset} className="btn-primary">Yeni Oyun</button>
        </div>
      )}
    </div>
  );
};

/* --- GAME 5: RPS (Galactic Duel) --- */
const RPSGame: React.FC = () => {
  const choices = [
    { id: 'rock', icon: '🪨', label: 'Meteor' },
    { id: 'paper', icon: '📜', label: 'Harita' },
    { id: 'scissors', icon: '✂️', label: 'Lazer' }
  ];
  const [result, setResult] = useState<{user: string, comp: string, outcome: string} | null>(null);

  const play = (choiceId: string) => {
    const compChoice = choices[Math.floor(Math.random() * choices.length)];
    let outcome = '';

    if (choiceId === compChoice.id) outcome = 'BERABERE';
    else if (
      (choiceId === 'rock' && compChoice.id === 'scissors') ||
      (choiceId === 'paper' && compChoice.id === 'rock') ||
      (choiceId === 'scissors' && compChoice.id === 'paper')
    ) outcome = 'KAZANDIN!';
    else outcome = 'KAYBETTİN';

    setResult({ user: choices.find(c => c.id === choiceId)!.icon, comp: compChoice.icon, outcome });
  };

  return (
    <div className="text-center w-full">
      <div className="flex justify-center gap-4 mb-8">
        {choices.map(c => (
          <button 
            key={c.id} 
            onClick={() => play(c.id)}
            className="flex flex-col items-center gap-1 group"
          >
            <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center text-3xl border border-white/10 group-hover:bg-cyan-900/40 group-hover:scale-110 transition-all">
              {c.icon}
            </div>
            <span className="text-xs text-gray-400">{c.label}</span>
          </button>
        ))}
      </div>
      
      {result && (
        <div className="animate-fade-in-up bg-black/30 p-3 rounded-lg border border-white/10">
          <div className="flex justify-center items-center text-2xl gap-4 mb-2">
            <span>{result.user}</span>
            <span className="text-sm text-gray-500">vs</span>
            <span>{result.comp}</span>
          </div>
          <p className={`font-bold ${result.outcome === 'KAZANDIN!' ? 'text-green-400' : result.outcome === 'KAYBETTİN' ? 'text-red-400' : 'text-gray-300'}`}>
            {result.outcome}
          </p>
        </div>
      )}
    </div>
  );
};

/* --- GAME 6: SIMON (Sequence) --- */
const SimonGame: React.FC = () => {
  const colors = ['red', 'green', 'blue', 'yellow'];
  const [sequence, setSequence] = useState<string[]>([]);
  const [playing, setPlaying] = useState(false);
  const [playingIdx, setPlayingIdx] = useState(0);
  const [userTurn, setUserTurn] = useState(false);
  const [userIdx, setUserIdx] = useState(0);
  const [flash, setFlash] = useState<string | null>(null);
  const [msg, setMsg] = useState('Başlamak için tıkla');

  useEffect(() => {
    if (playing) {
      if (playingIdx < sequence.length) {
        const color = sequence[playingIdx];
        setFlash(color);
        setTimeout(() => {
          setFlash(null);
          setTimeout(() => {
            setPlayingIdx(i => i + 1);
          }, 200); // gap between flashes
        }, 600); // flash duration
      } else {
        setUserTurn(true);
        setMsg('Senin Sıran');
      }
    }
  }, [playing, playingIdx, sequence]);

  const startGame = () => {
    setSequence([colors[Math.floor(Math.random() * colors.length)]]);
    setPlaying(true);
    setPlayingIdx(0);
    setUserTurn(false);
    setUserIdx(0);
    setMsg('İzle...');
  };

  const handleColorClick = (color: string) => {
    if (!userTurn) return;
    
    // Visual feedback
    setFlash(color);
    setTimeout(() => setFlash(null), 200);

    if (color === sequence[userIdx]) {
      if (userIdx + 1 === sequence.length) {
        // Round success
        setUserTurn(false);
        setMsg('Harika! Bekle...');
        setTimeout(() => {
          setSequence(prev => [...prev, colors[Math.floor(Math.random() * colors.length)]]);
          setPlayingIdx(0);
          setUserIdx(0);
          setMsg('İzle...');
        }, 1000);
      } else {
        setUserIdx(i => i + 1);
      }
    } else {
      setMsg(`Hata! Skor: ${sequence.length - 1}`);
      setPlaying(false);
      setUserTurn(false);
    }
  };

  return (
    <div className="flex flex-col items-center w-full">
      <p className="mb-4 text-sm font-bold text-cyan-300">{msg}</p>
      <div className="grid grid-cols-2 gap-4">
        <div 
          onClick={() => handleColorClick('red')}
          className={`w-20 h-20 rounded-tl-3xl bg-red-900/50 border-2 border-red-600 cursor-pointer transition-all duration-100 ${flash === 'red' ? 'bg-red-500 brightness-150 scale-105 shadow-[0_0_20px_red]' : ''}`} 
        />
        <div 
          onClick={() => handleColorClick('green')}
          className={`w-20 h-20 rounded-tr-3xl bg-green-900/50 border-2 border-green-600 cursor-pointer transition-all duration-100 ${flash === 'green' ? 'bg-green-500 brightness-150 scale-105 shadow-[0_0_20px_lime]' : ''}`} 
        />
        <div 
          onClick={() => handleColorClick('blue')}
          className={`w-20 h-20 rounded-bl-3xl bg-blue-900/50 border-2 border-blue-600 cursor-pointer transition-all duration-100 ${flash === 'blue' ? 'bg-blue-500 brightness-150 scale-105 shadow-[0_0_20px_cyan]' : ''}`} 
        />
        <div 
          onClick={() => handleColorClick('yellow')}
          className={`w-20 h-20 rounded-br-3xl bg-yellow-900/50 border-2 border-yellow-600 cursor-pointer transition-all duration-100 ${flash === 'yellow' ? 'bg-yellow-500 brightness-150 scale-105 shadow-[0_0_20px_yellow]' : ''}`} 
        />
      </div>
      {!playing && (
        <button onClick={startGame} className="mt-4 btn-primary text-xs px-4 py-2">
          {sequence.length > 0 ? 'Yeniden Başla' : 'Başlat'}
        </button>
      )}
    </div>
  );
};

/* --- GAME 7: SNAKE --- */
const SnakeGame: React.FC = () => {
  const GRID_SIZE = 15;
  const [snake, setSnake] = useState([{ x: 7, y: 7 }]);
  const [food, setFood] = useState({ x: 10, y: 5 });
  const [dir, setDir] = useState<'UP' | 'DOWN' | 'LEFT' | 'RIGHT'>('RIGHT');
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (!isPlaying) return;
    const move = setInterval(() => {
      setSnake(prev => {
        const head = { ...prev[0] };
        if (dir === 'UP') head.y -= 1;
        if (dir === 'DOWN') head.y += 1;
        if (dir === 'LEFT') head.x -= 1;
        if (dir === 'RIGHT') head.x += 1;

        if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
          setGameOver(true);
          setIsPlaying(false);
          return prev;
        }
        if (prev.some(s => s.x === head.x && s.y === head.y)) {
          setGameOver(true);
          setIsPlaying(false);
          return prev;
        }

        const newSnake = [head, ...prev];
        if (head.x === food.x && head.y === food.y) {
          setScore(s => s + 1);
          setFood({
            x: Math.floor(Math.random() * GRID_SIZE),
            y: Math.floor(Math.random() * GRID_SIZE)
          });
        } else {
          newSnake.pop();
        }
        return newSnake;
      });
    }, 150);
    return () => clearInterval(move);
  }, [isPlaying, dir, food]);

  const startGame = () => {
    setSnake([{ x: 7, y: 7 }]);
    setScore(0);
    setDir('RIGHT');
    setGameOver(false);
    setIsPlaying(true);
  };

  return (
    <div className="flex flex-col items-center w-full">
      <div className="flex justify-between w-full max-w-[250px] mb-2">
         <span className="text-cyan-300 font-bold">SKOR: {score}</span>
         {gameOver && <span className="text-red-400 font-bold">OYUN BİTTİ</span>}
      </div>
      
      <div className="relative bg-black/50 border border-white/10" style={{ width: 250, height: 250 }}>
        {!isPlaying && !gameOver && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 z-10">
            <button onClick={startGame} className="btn-primary">BAŞLA</button>
          </div>
        )}
        {gameOver && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 z-10">
             <button onClick={startGame} className="btn-primary">TEKRAR</button>
          </div>
        )}
        
        <div className="absolute bg-yellow-400 rounded-full shadow-[0_0_5px_yellow]"
             style={{ width: `${100/GRID_SIZE}%`, height: `${100/GRID_SIZE}%`, left: `${(food.x / GRID_SIZE) * 100}%`, top: `${(food.y / GRID_SIZE) * 100}%` }} />
        
        {snake.map((part, i) => (
          <div key={i} className="absolute bg-cyan-500 rounded-sm"
               style={{ width: `${100/GRID_SIZE}%`, height: `${100/GRID_SIZE}%`, left: `${(part.x / GRID_SIZE) * 100}%`, top: `${(part.y / GRID_SIZE) * 100}%` }} />
        ))}
      </div>

      <div className="grid grid-cols-3 gap-1 mt-2">
        <div />
        <button onClick={() => setDir('UP')} className="bg-white/10 p-2 rounded active:bg-cyan-700">⬆️</button>
        <div />
        <button onClick={() => setDir('LEFT')} className="bg-white/10 p-2 rounded active:bg-cyan-700">⬅️</button>
        <button onClick={() => setDir('DOWN')} className="bg-white/10 p-2 rounded active:bg-cyan-700">⬇️</button>
        <button onClick={() => setDir('RIGHT')} className="bg-white/10 p-2 rounded active:bg-cyan-700">➡️</button>
      </div>
    </div>
  );
};

/* --- GAME 8: SLOTS --- */
const SlotGame: React.FC = () => {
  const items = ['🚀', '👽', '🪐', '⭐️', '☄️'];
  const [slots, setSlots] = useState(['🚀', '🚀', '🚀']);
  const [spinning, setSpinning] = useState(false);
  const [message, setMessage] = useState('Çevir ve kazan!');

  const finishSpin = () => {
    setSpinning(false);
    const final = [items[Math.floor(Math.random() * items.length)], items[Math.floor(Math.random() * items.length)], items[Math.floor(Math.random() * items.length)]];
    setSlots(final);
    if (final[0] === final[1] && final[1] === final[2]) setMessage('🎉 JACKPOT! 🎉');
    else if (final[0] === final[1] || final[1] === final[2] || final[0] === final[2]) setMessage('Güzel! İkili tutturdun.');
    else setMessage('Tekrar dene!');
  };

  const spin = () => {
    if (spinning) return;
    setSpinning(true);
    setMessage('Dönüyor...');
    let count = 0;
    const interval = setInterval(() => {
      setSlots([items[Math.floor(Math.random() * items.length)], items[Math.floor(Math.random() * items.length)], items[Math.floor(Math.random() * items.length)]]);
      count++;
      if (count > 20) {
        clearInterval(interval);
        finishSpin();
      }
    }, 100);
  };

  return (
    <div className="flex flex-col items-center justify-center w-full text-center">
       <div className="bg-black/40 p-4 rounded-xl border border-purple-500/30 flex gap-2 mb-4">
          {slots.map((s, i) => (
            <div key={i} className="w-16 h-20 bg-gradient-to-b from-gray-800 to-black border border-white/10 rounded flex items-center justify-center text-4xl">{s}</div>
          ))}
       </div>
       <p className="text-cyan-300 font-bold mb-4 h-6">{message}</p>
       <button onClick={spin} disabled={spinning} className={`btn-primary w-32 ${spinning ? 'opacity-50' : ''}`}>
         {spinning ? '...' : 'ÇEVİR'}
       </button>
    </div>
  );
};

/* --- GAME 9: MATH --- */
const MathGame: React.FC = () => {
  const [q, setQ] = useState({ t: '', a: 0 });
  const [options, setOptions] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (playing && timeLeft > 0) {
      const t = setInterval(() => setTimeLeft(p => p - 1), 1000);
      return () => clearInterval(t);
    } else if (timeLeft === 0) {
      setPlaying(false);
    }
  }, [playing, timeLeft]);

  const generateQ = () => {
    const op = Math.random() > 0.5 ? '+' : '-';
    const n1 = Math.floor(Math.random() * 20) + 1;
    const n2 = Math.floor(Math.random() * 10) + 1;
    const ans = op === '+' ? n1 + n2 : n1 - n2;
    const opts = new Set([ans]);
    while (opts.size < 3) opts.add(ans + Math.floor(Math.random() * 10) - 5);
    setQ({ t: `${n1} ${op} ${n2} = ?`, a: ans });
    setOptions(Array.from(opts).sort(() => Math.random() - 0.5));
  };

  const start = () => {
    setScore(0);
    setTimeLeft(15);
    setPlaying(true);
    generateQ();
  };

  const answer = (val: number) => {
    if (val === q.a) {
      setScore(s => s + 1);
      setTimeLeft(t => t + 2);
      generateQ();
    } else {
      setTimeLeft(t => Math.max(0, t - 3));
    }
  };

  if (!playing) return (
    <div className="text-center">
      <h3 className="text-lg text-cyan-300 mb-2">Toplam Yakıt: {score}</h3>
      <p className="text-sm text-gray-400 mb-4">Süre bitmeden doğru işlemleri yap!</p>
      <button onClick={start} className="btn-primary">Motorları Çalıştır</button>
    </div>
  );

  return (
    <div className="text-center w-full">
      <div className="flex justify-between text-sm font-bold mb-4 px-4">
        <span className="text-cyan-400">Skor: {score}</span>
        <span className={`${timeLeft < 5 ? 'text-red-500 animate-pulse' : 'text-white'}`}>Süre: {timeLeft}s</span>
      </div>
      <div className="text-4xl font-bold text-white mb-8">{q.t}</div>
      <div className="grid grid-cols-3 gap-3">
        {options.map((opt, i) => (
          <button key={i} onClick={() => answer(opt)} className="py-4 bg-white/10 rounded-lg hover:bg-cyan-600 transition-colors text-xl font-bold">{opt}</button>
        ))}
      </div>
    </div>
  );
};

/* ================= NEW GAMES (11 NEW) ================= */

/* --- GAME 10: DOCKING (Kenetlenme) --- */
const DockingGame: React.FC = () => {
  const [pos, setPos] = useState(0);
  const [direction, setDirection] = useState(1);
  const [playing, setPlaying] = useState(false);
  const [message, setMessage] = useState("Hazır olduğunda Kenetlen'e bas");
  const requestRef = useRef<number>();

  const animate = () => {
    setPos(prev => {
      if (prev > 95) setDirection(-1);
      if (prev < 5) setDirection(1);
      return prev + (direction * 1.5); // speed
    });
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    if (playing) requestRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(requestRef.current!);
  }, [playing, direction]);

  const stop = () => {
    setPlaying(false);
    cancelAnimationFrame(requestRef.current!);
    if (pos > 40 && pos < 60) setMessage("BAŞARILI KENETLENME! 🚀");
    else setMessage("BAŞARISIZ! Tekrar dene.");
  };

  const start = () => {
    setPos(0);
    setPlaying(true);
    setMessage("HEDEF: ORTA NOKTA");
  };

  return (
    <div className="w-full text-center">
      <div className="w-full h-12 bg-gray-800 rounded-full relative overflow-hidden mb-4 border border-white/10">
        {/* Target Zone */}
        <div className="absolute left-1/2 top-0 bottom-0 w-[20%] -translate-x-1/2 bg-green-900/50 border-x border-green-500"></div>
        {/* Mover */}
        <div 
          className="absolute top-1 bottom-1 w-4 bg-cyan-400 rounded-full shadow-[0_0_10px_cyan]"
          style={{ left: `${pos}%` }}
        ></div>
      </div>
      <p className={`mb-4 font-bold ${message.includes('BAŞARILI') ? 'text-green-400' : 'text-cyan-200'}`}>{message}</p>
      <button onClick={playing ? stop : start} className="btn-primary w-40">
        {playing ? 'KENETLEN' : 'BAŞLAT'}
      </button>
    </div>
  );
};

/* --- GAME 11: MOLE (Uzaylı Avı) --- */
const MoleGame: React.FC = () => {
  const [activeIdx, setActiveIdx] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (playing && timeLeft > 0) {
      const t = setInterval(() => setTimeLeft(p => p - 1), 1000);
      const m = setInterval(() => setActiveIdx(Math.floor(Math.random() * 9)), 600);
      return () => { clearInterval(t); clearInterval(m); };
    } else if (timeLeft === 0) {
      setPlaying(false);
      setActiveIdx(null);
    }
  }, [playing, timeLeft]);

  const whack = (idx: number) => {
    if (idx === activeIdx) {
      setScore(s => s + 1);
      setActiveIdx(null);
    }
  };

  const start = () => {
    setScore(0);
    setTimeLeft(15);
    setPlaying(true);
  };

  if (!playing) return (
    <div className="text-center">
      <h3 className="text-lg text-cyan-300 mb-2">Skor: {score}</h3>
      <button onClick={start} className="btn-primary">Uzaylıları Yakala</button>
    </div>
  );

  return (
    <div className="text-center">
      <div className="mb-2 flex justify-between px-4 font-bold">
        <span className="text-yellow-400">Skor: {score}</span>
        <span className="text-white">Süre: {timeLeft}</span>
      </div>
      <div className="grid grid-cols-3 gap-3 max-w-[200px] mx-auto">
        {Array.from({length: 9}).map((_, i) => (
          <div 
            key={i} 
            onMouseDown={() => whack(i)}
            className={`h-16 rounded-lg bg-white/10 flex items-center justify-center text-3xl cursor-pointer transition-all duration-75 active:scale-90 border border-white/5 ${activeIdx === i ? 'bg-green-900/60' : ''}`}
          >
            {activeIdx === i ? '👽' : ''}
          </div>
        ))}
      </div>
    </div>
  );
};

/* --- GAME 12: CLICKER (Foton Toplayıcı) --- */
const ClickerGame: React.FC = () => {
  const [clicks, setClicks] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (playing && timeLeft > 0) {
      const t = setInterval(() => setTimeLeft(p => p - 0.1), 100);
      return () => clearInterval(t);
    } else if (timeLeft <= 0) {
      setPlaying(false);
    }
  }, [playing, timeLeft]);

  const start = () => {
    setClicks(0);
    setTimeLeft(10);
    setPlaying(true);
  };

  const click = () => {
    if (playing) setClicks(c => c + 1);
  };

  return (
    <div className="text-center w-full">
      <div className="text-4xl font-bold text-yellow-400 mb-2">{clicks}</div>
      <div className="text-sm text-gray-400 mb-6">FOTON</div>
      
      {!playing ? (
         <div>
           <p className="mb-4 text-cyan-200">{clicks > 0 ? `Süre doldu! Skorun: ${clicks}` : '10 saniyede kaç foton toplayabilirsin?'}</p>
           <button onClick={start} className="btn-primary">BAŞLA</button>
         </div>
      ) : (
         <div>
           <div className="w-full bg-gray-700 h-2 rounded-full mb-4 overflow-hidden">
             <div className="bg-cyan-500 h-full transition-all duration-100 ease-linear" style={{ width: `${(timeLeft / 10) * 100}%` }}></div>
           </div>
           <button 
             onMouseDown={click}
             className="w-24 h-24 rounded-full bg-gradient-to-b from-red-500 to-red-700 text-white font-bold shadow-[0_0_20px_red] active:scale-90 transition-transform flex items-center justify-center text-xl mx-auto"
           >
             TIKLA!
           </button>
         </div>
      )}
    </div>
  );
};

/* --- GAME 13: HIGHLOW (Yıldız Falı) --- */
const HighLowGame: React.FC = () => {
  const [curr, setCurr] = useState(50);
  const [next, setNext] = useState(0);
  const [score, setScore] = useState(0);
  const [msg, setMsg] = useState("Sıradaki sayı büyük mü küçük mü?");

  const predict = (isHigher: boolean) => {
    const newVal = Math.floor(Math.random() * 100) + 1;
    setNext(newVal);
    
    if ((isHigher && newVal > curr) || (!isHigher && newVal < curr)) {
      setScore(s => s + 1);
      setMsg("DOĞRU! Devam et.");
    } else {
      setScore(0);
      setMsg("YANLIŞ! Skor sıfırlandı.");
    }
    setCurr(newVal);
  };

  return (
    <div className="text-center w-full">
      <div className="text-6xl font-bold text-white mb-4 orbitron">{curr}</div>
      <p className="text-cyan-300 mb-6 min-h-[24px]">{msg}</p>
      
      <div className="flex justify-center gap-4 mb-6">
        <button onClick={() => predict(false)} className="btn-secondary px-6">DÜŞÜK ▼</button>
        <button onClick={() => predict(true)} className="btn-primary px-6">YÜKSEK ▲</button>
      </div>
      <p className="text-gray-500 text-sm">Seri: {score}</p>
    </div>
  );
};

/* --- GAME 14: LIGHTS OUT (Enerji Ağı) --- */
const LightsOutGame: React.FC = () => {
  const [grid, setGrid] = useState([false, false, false, false, false, false, false, false, false]);

  const toggle = (i: number) => {
    const newGrid = [...grid];
    const toggleCell = (idx: number) => {
      if (idx >= 0 && idx < 9) newGrid[idx] = !newGrid[idx];
    };
    
    toggleCell(i);
    if (i % 3 !== 0) toggleCell(i - 1); // left
    if (i % 3 !== 2) toggleCell(i + 1); // right
    if (i >= 3) toggleCell(i - 3); // up
    if (i < 6) toggleCell(i + 3); // down
    
    setGrid(newGrid);
  };

  const init = () => {
    // Create solvable board by starting clean and simulating clicks
    const g = Array(9).fill(false);
    const tempGrid = [...g];
    for(let i=0; i<5; i++) {
       const r = Math.floor(Math.random() * 9);
       // simulate click logic roughly to randomize
       tempGrid[r] = !tempGrid[r];
       if (r%3!==0) tempGrid[r-1] = !tempGrid[r-1];
       if (r%3!==2) tempGrid[r+1] = !tempGrid[r+1];
       if (r>=3) tempGrid[r-3] = !tempGrid[r-3];
       if (r<6) tempGrid[r+3] = !tempGrid[r+3];
    }
    setGrid(tempGrid);
  };
  
  useEffect(() => { init(); }, []);

  const solved = grid.every(c => !c);

  return (
    <div className="text-center">
      <p className="mb-4 text-sm text-gray-300">Tüm ışıkları kapat!</p>
      {solved ? (
        <div>
          <div className="text-4xl mb-2">💡</div>
          <p className="text-green-400 font-bold mb-4">SİSTEM KAPALI!</p>
          <button onClick={init} className="btn-primary">Yeniden</button>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-2 mx-auto w-48">
          {grid.map((lit, i) => (
            <div 
              key={i}
              onClick={() => toggle(i)}
              className={`aspect-square rounded border cursor-pointer transition-all duration-200 ${lit ? 'bg-yellow-400 shadow-[0_0_15px_yellow] border-yellow-200' : 'bg-gray-800 border-gray-600'}`}
            />
          ))}
        </div>
      )}
    </div>
  );
};

/* --- GAME 15: JUMP (Ay Zıplaması) --- */
const JumpGame: React.FC = () => {
  const [power, setPower] = useState(0);
  const [charging, setCharging] = useState(false);
  const [target, setTarget] = useState(0);
  const [message, setMessage] = useState('Basılı tut ve hedefi tuttur');
  const reqRef = useRef<number>();

  useEffect(() => {
    setTarget(Math.floor(Math.random() * 60) + 20); // 20-80
  }, []);

  const loop = () => {
    setPower(p => {
      if (p >= 100) return 0;
      return p + 2;
    });
    reqRef.current = requestAnimationFrame(loop);
  };

  const handleDown = () => {
    setPower(0);
    setCharging(true);
    setMessage('Güçleniyor...');
    loop();
  };

  const handleUp = () => {
    setCharging(false);
    cancelAnimationFrame(reqRef.current!);
    const diff = Math.abs(power - target);
    if (diff < 5) setMessage('MÜKEMMEL İNİŞ! 🌕');
    else if (diff < 15) setMessage('Güvenli İniş.');
    else setMessage('ÇAKILDIN! 💥');
  };

  return (
    <div className="w-full text-center select-none">
      <div className="relative w-full h-8 bg-gray-800 rounded-full mb-2 overflow-hidden border border-white/10">
        {/* Target Marker */}
        <div 
          className="absolute top-0 bottom-0 bg-green-500/30 border-x border-green-500 z-0"
          style={{ left: `${target - 5}%`, width: '10%' }}
        />
        {/* Power Bar */}
        <div 
          className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-cyan-500 to-purple-500 z-10 opacity-70"
          style={{ width: `${power}%` }}
        />
      </div>
      
      <p className={`mb-6 font-bold h-6 ${message.includes('ÇAKIL') ? 'text-red-400' : message.includes('MÜKEMMEL') ? 'text-yellow-400' : 'text-cyan-200'}`}>
        {message}
      </p>
      
      <button 
        onMouseDown={handleDown}
        onMouseUp={handleUp}
        onMouseLeave={() => { if(charging) handleUp(); }}
        onTouchStart={handleDown}
        onTouchEnd={handleUp}
        className="w-24 h-24 rounded-full bg-white/10 border-4 border-cyan-500/50 flex items-center justify-center active:scale-95 transition-all mx-auto"
      >
        <span className="text-2xl">🚀</span>
      </button>
    </div>
  );
};

/* --- GAME 16: LOCK (Yörünge Kilidi) --- */
const LockGame: React.FC = () => {
  const [rotation, setRotation] = useState(0);
  const [target, setTarget] = useState(Math.random() * 360);
  const [spinning, setSpinning] = useState(true);
  const [msg, setMsg] = useState('Kilidi Aç');

  useEffect(() => {
    let r = 0;
    const int = setInterval(() => {
      if(spinning) {
        r = (r + 5) % 360;
        setRotation(r);
      }
    }, 20);
    return () => clearInterval(int);
  }, [spinning]);

  const check = () => {
    setSpinning(false);
    const diff = Math.abs(rotation - target);
    // Handle wrap around difference (e.g. 359 vs 1)
    const normalizedDiff = Math.min(diff, 360 - diff);
    
    if (normalizedDiff < 15) {
      setMsg('AÇILDI 🔓');
      setTimeout(() => {
        setTarget(Math.random() * 360);
        setSpinning(true);
        setMsg('Kilidi Aç');
      }, 1500);
    } else {
      setMsg('BAŞARISIZ 🔒');
      setTimeout(() => {
        setSpinning(true);
        setMsg('Kilidi Aç');
      }, 1000);
    }
  };

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-40 h-40 rounded-full border-4 border-gray-700 bg-gray-900 mb-4 flex items-center justify-center shadow-inner cursor-pointer" onClick={check}>
        {/* Target Zone */}
        <div 
          className="absolute w-4 h-4 bg-green-500 rounded-full top-1"
          style={{ transformOrigin: 'center 72px', transform: `rotate(${target}deg)` }}
        />
        
        {/* Spinner */}
        <div 
          className="absolute w-1 h-16 bg-cyan-400 top-4 origin-bottom rounded-full shadow-[0_0_10px_cyan]"
          style={{ transform: `rotate(${rotation}deg)` }}
        />
        
        <div className="w-8 h-8 bg-gray-600 rounded-full z-10 border-2 border-gray-500" />
      </div>
      <p className={`font-bold ${msg.includes('AÇILDI') ? 'text-green-400' : msg.includes('BAŞARISIZ') ? 'text-red-400' : 'text-white'}`}>{msg}</p>
      <p className="text-xs text-gray-500 mt-2">Yeşil noktada durdurmak için tıkla</p>
    </div>
  );
};

/* --- GAME 17: DIFFERENCE (Kamuflaj) --- */
const DifferenceGame: React.FC = () => {
  const sets = [
    { main: '🚀', diff: '🛸' },
    { main: '⭐', diff: '🌟' },
    { main: '👨‍🚀', diff: '🧟' },
    { main: '🌑', diff: '🌚' },
  ];
  const [items, setItems] = useState<string[]>([]);
  const [msg, setMsg] = useState('Farklı olanı bul');

  const init = () => {
    const set = sets[Math.floor(Math.random() * sets.length)];
    const arr = Array(4).fill(set.main);
    const diffIdx = Math.floor(Math.random() * 4);
    arr[diffIdx] = set.diff;
    setItems(arr);
    setMsg('Farklı olanı bul');
  };

  useEffect(init, []);

  const pick = (item: string) => {
    // Determine which is the odd one out
    // A simple way: count occurences or just compare with known 'diff' if we stored it.
    // But let's reconstruct logic: if item is unique in array?
    const count = items.filter(i => i === item).length;
    if (count === 1) {
      setMsg('DOĞRU! 👁️');
      setTimeout(init, 1000);
    } else {
      setMsg('YANLIŞ');
    }
  };

  return (
    <div className="text-center w-full">
      <p className={`mb-6 font-bold min-h-[24px] ${msg === 'YANLIŞ' ? 'text-red-400' : 'text-cyan-300'}`}>{msg}</p>
      <div className="grid grid-cols-2 gap-4 max-w-[200px] mx-auto">
        {items.map((item, i) => (
          <button 
            key={i}
            onClick={() => pick(item)}
            className="text-5xl p-4 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 transition-all active:scale-95"
          >
            {item}
          </button>
        ))}
      </div>
    </div>
  );
};

/* --- GAME 18: QUIZ (Astro Bilgi) --- */
const QuizGame: React.FC = () => {
  const questions = [
    { q: 'Güneş sistemindeki en büyük gezegen Jüpiter\'dir.', a: true },
    { q: 'Işık yılı bir zaman ölçü birimidir.', a: false },
    { q: 'Mars "Kızıl Gezegen" olarak bilinir.', a: true },
    { q: 'Ay, Dünya\'nın tek doğal uydusudur.', a: true },
    { q: 'Güneş bir yıldızdır.', a: true },
    { q: 'Uzayda ses yayılabilir.', a: false },
  ];
  const [qIdx, setQIdx] = useState(0);
  const [msg, setMsg] = useState('');
  const [answered, setAnswered] = useState(false);

  const answer = (val: boolean) => {
    if (answered) return;
    setAnswered(true);
    if (val === questions[qIdx].a) {
      setMsg('DOĞRU! ✅');
      setTimeout(() => {
        setQIdx(i => (i + 1) % questions.length);
        setMsg('');
        setAnswered(false);
      }, 1500);
    } else {
      setMsg('YANLIŞ ❌');
      setTimeout(() => {
        setMsg('');
        setAnswered(false);
      }, 1500);
    }
  };

  return (
    <div className="text-center w-full px-4">
      <div className="min-h-[100px] flex items-center justify-center mb-4">
        <p className="text-lg font-medium leading-snug">{questions[qIdx].q}</p>
      </div>
      
      {msg && <p className={`font-bold mb-4 ${msg.includes('DOĞRU') ? 'text-green-400' : 'text-red-400'}`}>{msg}</p>}
      
      <div className="flex gap-4 justify-center">
        <button 
          onClick={() => answer(true)} 
          className="bg-green-600 hover:bg-green-500 text-white px-6 py-3 rounded-lg font-bold w-32 transition-colors"
        >
          DOĞRU
        </button>
        <button 
          onClick={() => answer(false)} 
          className="bg-red-600 hover:bg-red-500 text-white px-6 py-3 rounded-lg font-bold w-32 transition-colors"
        >
          YANLIŞ
        </button>
      </div>
    </div>
  );
};

/* --- GAME 19: PATTERN (Yıldız Haritası) --- */
const PatternGame: React.FC = () => {
  const [pattern, setPattern] = useState<number[]>([]);
  const [userPattern, setUserPattern] = useState<number[]>([]);
  const [phase, setPhase] = useState<'memorize' | 'recall' | 'success' | 'fail'>('memorize');

  const init = () => {
    const p = [];
    while(p.length < 3) {
      const r = Math.floor(Math.random() * 9);
      if(!p.includes(r)) p.push(r);
    }
    setPattern(p);
    setUserPattern([]);
    setPhase('memorize');
    setTimeout(() => setPhase('recall'), 1500);
  };

  useEffect(init, []);

  const click = (i: number) => {
    if (phase !== 'recall') return;
    
    const newUP = [...userPattern, i];
    setUserPattern(newUP);

    // Check validity immediately
    if (!pattern.includes(i)) {
      setPhase('fail');
      setTimeout(init, 1500);
      return;
    }

    if (newUP.length === pattern.length) {
      // Order doesn't matter for this version, just set membership
      const sortedP = [...pattern].sort();
      const sortedUP = [...newUP].sort();
      if (JSON.stringify(sortedP) === JSON.stringify(sortedUP)) {
        setPhase('success');
        setTimeout(init, 1500);
      }
    }
  };

  return (
    <div className="text-center">
      <p className="mb-4 text-cyan-200 h-6">
        {phase === 'memorize' ? 'Deseni ezberle...' : phase === 'recall' ? 'İşaretli yerleri seç' : phase === 'success' ? 'MÜKEMMEL!' : 'YANLIŞ!'}
      </p>
      <div className="grid grid-cols-3 gap-2 mx-auto w-48">
        {Array.from({length: 9}).map((_, i) => {
          let bg = 'bg-white/10';
          if (phase === 'memorize' && pattern.includes(i)) bg = 'bg-cyan-400 shadow-[0_0_10px_cyan]';
          if ((phase === 'recall' || phase === 'success') && userPattern.includes(i)) bg = 'bg-cyan-600';
          if (phase === 'fail' && userPattern.includes(i) && !pattern.includes(i)) bg = 'bg-red-500';

          return (
            <div 
              key={i}
              onClick={() => click(i)}
              className={`aspect-square rounded cursor-pointer border border-white/5 transition-colors duration-200 ${bg}`}
            />
          );
        })}
      </div>
    </div>
  );
};

/* --- GAME 20: STROOP (Renk Reaktörü) --- */
const StroopGame: React.FC = () => {
  const colors = [
    { name: 'KIRMIZI', hex: '#EF4444', val: 'red' },
    { name: 'MAVİ', hex: '#3B82F6', val: 'blue' },
    { name: 'YEŞİL', hex: '#22C55E', val: 'green' },
    { name: 'SARI', hex: '#EAB308', val: 'yellow' }
  ];
  
  const [current, setCurrent] = useState({ text: '', colorHex: '', colorVal: '' });
  const [score, setScore] = useState(0);
  const [msg, setMsg] = useState('Yazının rengi ne?');

  const next = () => {
    const c1 = colors[Math.floor(Math.random() * colors.length)];
    const c2 = colors[Math.floor(Math.random() * colors.length)]; // can be same or diff
    setCurrent({ text: c1.name, colorHex: c2.hex, colorVal: c2.val });
  };

  useEffect(next, []);

  const check = (val: string) => {
    if (val === current.colorVal) {
      setScore(s => s + 1);
      setMsg('DOĞRU!');
      next();
    } else {
      setScore(0);
      setMsg('YANLIŞ! Sıfırlandın.');
      next();
    }
  };

  return (
    <div className="text-center w-full">
      <p className="text-gray-400 text-xs uppercase mb-2">AŞAĞIDAKİ YAZININ RENGİ NE?</p>
      <div 
        className="text-5xl font-bold mb-8 orbitron tracking-wider"
        style={{ color: current.colorHex }}
      >
        {current.text}
      </div>
      
      <p className="mb-4 font-bold text-white h-6">{msg} (Skor: {score})</p>

      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => check('red')} className="btn-secondary border-red-500/50 hover:bg-red-900/30">KIRMIZI</button>
        <button onClick={() => check('blue')} className="btn-secondary border-blue-500/50 hover:bg-blue-900/30">MAVİ</button>
        <button onClick={() => check('green')} className="btn-secondary border-green-500/50 hover:bg-green-900/30">YEŞİL</button>
        <button onClick={() => check('yellow')} className="btn-secondary border-yellow-500/50 hover:bg-yellow-900/30">SARI</button>
      </div>
    </div>
  );
};

export default MiniGames;
