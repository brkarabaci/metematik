import React, { useState } from 'react';
import { calculateCarbs } from '../services/geminiService';
import { CarbResult, Status } from '../types';

const CarbCalculator: React.FC = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<CarbResult | null>(null);
  const [status, setStatus] = useState<Status>(Status.IDLE);
  const [error, setError] = useState<string | null>(null);

  const handleCalculate = async () => {
    if (!input.trim()) return;

    setStatus(Status.LOADING);
    setError(null);
    setResult(null);

    try {
      const data = await calculateCarbs(input);
      setResult(data);
      setStatus(Status.SUCCESS);
    } catch (err: any) {
      setError(err.message || "Bir hata oluştu.");
      setStatus(Status.ERROR);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto px-6 relative z-10 mt-2 flex flex-col gap-4">
      
      {/* Result Card */}
      {status === Status.SUCCESS && result && (
        <div className="bg-gradient-to-br from-green-900/40 to-emerald-900/40 backdrop-blur-lg rounded-2xl p-5 border border-green-500/30 shadow-[0_0_20px_rgba(16,185,129,0.2)] animate-fade-in-up order-first">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-200 text-xs uppercase tracking-wider mb-1">Toplam Karbonhidrat</p>
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-bold text-white orbitron">{result.total_carbs}</span>
                <span className="text-xl text-green-300 font-medium">g</span>
              </div>
            </div>
            <div className="text-6xl filter drop-shadow-lg animate-bounce-slow">
              {result.icon}
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10">
            <p className="text-sm text-gray-300 leading-snug">
              {result.summary}
            </p>
          </div>
        </div>
      )}

      {/* Error Message */}
      {status === Status.ERROR && (
        <div className="bg-red-900/50 backdrop-blur-md p-4 rounded-xl border border-red-500/40 text-red-200 text-sm flex items-center gap-2">
          <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          {error}
        </div>
      )}

      {/* Input Area */}
      <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-1 border border-white/10 shadow-xl">
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (status !== Status.LOADING) {
                  handleCalculate();
                }
              }
            }}
            placeholder="Örn: 100 gr makarna ve 1 kase yoğurt..."
            className="w-full h-24 bg-black/20 text-white placeholder-gray-400 p-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500/50 resize-none text-lg transition-all"
            disabled={status === Status.LOADING}
          />
        </div>
        <button
          onClick={handleCalculate}
          disabled={status === Status.LOADING || !input.trim()}
          className={`w-full mt-1 py-4 rounded-xl font-bold text-lg tracking-widest transition-all duration-300 flex items-center justify-center gap-2 overflow-hidden relative
            ${status === Status.LOADING 
              ? 'bg-gray-600 cursor-not-allowed text-gray-400' 
              : 'bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white shadow-[0_0_20px_rgba(168,85,247,0.4)] hover:shadow-[0_0_30px_rgba(34,211,238,0.6)] active:scale-[0.98]'
            }`}
        >
          {status === Status.LOADING ? (
            <>
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span>HESAPLANIYOR...</span>
            </>
          ) : (
            <>
              <span>HESAPLA</span>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
            </>
          )}
        </button>
      </div>
      
      <style>{`
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.5s ease-out forwards;
        }
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(-5%); }
          50% { transform: translateY(5%); }
        }
        .animate-bounce-slow {
          animation: bounce-slow 3s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default CarbCalculator;