import React, { useEffect, useState } from 'react';

const Header: React.FC = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="w-full p-4 flex flex-col items-center justify-center relative z-10 mb-2">
      <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 tracking-wider drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]">
        MeteMatik
      </h1>
      <div className="mt-2 bg-white/10 backdrop-blur-sm px-6 py-1 rounded-full border border-white/10 shadow-lg">
        <span className="orbitron text-xl md:text-2xl text-cyan-100 tracking-widest">
          {time.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </header>
  );
};

export default Header;