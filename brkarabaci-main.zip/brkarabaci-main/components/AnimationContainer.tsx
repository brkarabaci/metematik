
import React, { useState, useRef } from 'react';

const AnimationContainer: React.FC = () => {
  const [mediaSrc, setMediaSrc] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleContainerClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setMediaSrc(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto px-6 relative z-10 mb-6 flex-shrink-0 mt-auto">
      
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        className="hidden" 
        accept="image/gif, image/jpeg, image/png, image/webp"
      />

      <div 
        onClick={handleContainerClick}
        id="animation-container" 
        className="w-full aspect-video bg-black/30 backdrop-blur-md rounded-xl border border-white/10 shadow-[0_0_15px_rgba(168,85,247,0.2)] flex items-center justify-center overflow-hidden group transition-all duration-500 hover:shadow-[0_0_25px_rgba(34,211,238,0.3)] cursor-pointer relative"
      >
        {mediaSrc ? (
          <>
            <img 
              src={mediaSrc} 
              alt="User animation" 
              className="w-full h-full object-cover animate-fade-in"
            />
            {/* Overlay hint on hover */}
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="text-white font-light tracking-wider orbitron text-sm">DEĞİŞTİR</span>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center text-white/30 group-hover:text-white/50 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mb-2 group-hover:scale-110 transition-transform duration-300">
              <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
            </svg>
            <span className="text-sm font-light tracking-wide">GIF/Fotoğraf Ekle</span>
          </div>
        )}
      </div>
      
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.5s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default AnimationContainer;
