import { GoogleGenAI, Type } from "@google/genai";
import { CarbResult } from "../types";

const getApiKey = (): string => {
  // In a real environment, this comes from process.env.API_KEY
  // The system prompt guarantees this is available.
  return process.env.API_KEY || '';
};

export const calculateCarbs = async (userInput: string): Promise<CarbResult> => {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error("API Key is missing");
  }

  const ai = new GoogleGenAI({ apiKey });

  const systemInstruction = `
    Sen uzman bir diyetisyensin. Kullanıcının girdiği yiyeceklerin toplam karbonhidrat değerini hesapla.
    Varsayımlar: Yiyecekler aksi belirtilmedikçe 'PİŞMİŞ' olarak kabul edilecek (örneğin '100 gr makarna' dendiğinde 'haşlanmış makarna' değeri baz alınacak).
    Eğer karbonhidrat değeri bir aralık ise (örn: 11-13), ortalamasını al (örn: 12).
    
    ÖZEL HESAPLAMA KURALLARI:
    1. EKMEK: Eğer içerik "ekmek" içeriyorsa (türü ne olursa olsun), ekmek kısmı için her zaman ağırlığının %60'ı kadar karbonhidrat içerdiğini varsay. (Örnek: 100 gr ekmek = 60 gr karbonhidrat. 1 gr ekmek = 0.6 gr karbonhidrat).
    
    Sindirime göre bir emoji seç:
    - Eğer yiyecek "ekmek" ise veya ağırlıklı olarak ekmek içeriyorsa: 🌮
    - Yağ oranı çok yüksek veya emilimi yavaşsa (örn: pizza, kebap, yağlı yemekler): 🍕
    - Şeker oranı çok yüksek veya emilimi çok hızlıysa (örn: meyve suyu, şekerleme): 🍭
    - Dengeli veya normal yemeklerse: 🌮
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userInput,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            total_carbs: {
              type: Type.NUMBER,
              description: "Toplam karbonhidrat miktarı (gram cinsinden)",
            },
            icon: {
              type: Type.STRING,
              description: "Yemeğin türüne göre seçilen emoji (🍕, 🍭, veya 🌮)",
            },
            summary: {
              type: Type.STRING,
              description: "Hesaplamanın kısa özeti (örn: 100gr haşlanmış makarna (25g) + 1 elma (15g))",
            },
          },
          required: ["total_carbs", "icon", "summary"],
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response text from Gemini");
    }

    const result = JSON.parse(text) as CarbResult;
    return result;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Hesaplama sırasında bir hata oluştu. Lütfen tekrar deneyin.");
  }
};